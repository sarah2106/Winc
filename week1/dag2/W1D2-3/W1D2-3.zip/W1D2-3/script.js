
console.log("Hallo Winc Academy Studenten")
console.log("Hello Winc Academy");
let name = "Sarah";
console.log(name);
// Dit is een grote som
let sum = 1230941 * 1823794;
console.log("eerst som:", sum);
let division = 637263 / 54;
console.log("division:", division);




