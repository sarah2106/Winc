let name = 'Sarah';
console.log(name);


// cannoit be a reserved keyboard
// Should be meaningful
// Cannot start with a number (1name)
// Cannot cantain a space a hyphen (-)

let firstName = 'Sarah';
let lastname = 'Eitjes';
let age = '31';

