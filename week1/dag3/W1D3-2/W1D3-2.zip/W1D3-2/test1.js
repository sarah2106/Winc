 //Make a sandwhichpeanutbutter ____
 //step 1 Choose a sandwich step. 
 // 2 add peanutbutter.
//step 3 enjoy your sandwich.

const sandwhichpeanutbutter = function ()  {
    console.log("  Choose a sandwich");
	console.log("  add peanutbutter");
	console.log("  enjoy your sandwich");
};
sandwhichpeanutbutter();