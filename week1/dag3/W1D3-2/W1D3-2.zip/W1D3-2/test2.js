const makeSandwich = function (topping) {
    console.log("Choose a sandwich");
	console.log("Add " + topping + " to sandwich");
    console.log("enjoy your sandwich with ++ topping");
};
makeSandwich();

makeSandwich('cheese');
makeSandwich('ham');