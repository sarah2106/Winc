function tellFortune(jobTitle, geographiclocation, partner, numberofchildren) {
    let future = 'You will be a ' + jobTitle + ' in ' + geographiclocation + ' get married' +
   partner + ' ' + ' with ' + numberofchildren + ' kids.';
    console.log(future);
}

tellFortune('bball player', 'Germany', 'Thomas', 3);
tellFortune('stunt double', 'Netherlands', 'Thomas beiling', 3000);
tellFortune('Jan smit', 'France', 'singer', 0);