function calculateDogAge(age) {
    let dogYears = 3*age;
    console.log("Your doggie is " + dogYears + " years old in dog years!");
}

calculateDogAge(2);
